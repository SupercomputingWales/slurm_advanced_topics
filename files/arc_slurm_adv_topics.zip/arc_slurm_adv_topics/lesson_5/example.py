#!/bin/env python3
import sys
from numpy.random import normal
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot
# define the distribution
mu = 50
sigma = 5
ID=int(sys.argv[1])

sample = normal(mu, sigma, 1000)
pyplot.hist(sample, bins=20)
pyplot.title('1000 samples - ArrayID %d' % ID )
f='fig'+str(ID)+'.png'
pyplot.savefig(f,format="png")
pyplot.close()
print("done")
