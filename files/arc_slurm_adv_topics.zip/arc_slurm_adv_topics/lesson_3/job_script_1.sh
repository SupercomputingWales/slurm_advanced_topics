#!/bin/bash --login
#SBATCH -J my.job
#SBATCH -o %x.o.%j
#SBATCH -e %x.e.%j
#SBATCH --ntasks=5
#SBATCH --ntasks-per-node=5
#SBATCH -p dev
#SBATCH --time=00:05:00
#SBATCH --account=scwXXXX

# some commands specific to your job
# for example:
env | grep SLURM
sleep 120
echo “Hello World!”
