#!/bin/bash

MYPTH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  mkdir $MYPATH
fi
touch $MYPATH/file
