#!/bin/bash

# Trap undefined variables.
set -eu

MYPATH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  mkdir $MYPATH || echo "ERROR: Failed to create directory." && exit 1
fi
touch $MYPATH/file
