#!/bin/bash

# Trap undefined variables.
set -u

MYPTH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  mkdir $MYPATH
fi
touch $MYPATH/file
