#!/bin/bash

# Trap undefined variables.
set -eu

MYPATH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  mkdir $MYPATH
fi
touch $MYPATH/file
