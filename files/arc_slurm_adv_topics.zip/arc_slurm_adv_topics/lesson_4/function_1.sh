#!/bin/bash

# Trap undefined variables.
set -eu

MYPATH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  mkdir -p $MYPATH || ( echo "ERROR: Failed to create directory." && exit 1 )
fi
touch $MYPATH/file

mkdir $MYPATH/output || ( echo "ERROR: Failed to create directory." && exit 1 )
mkdir $MYPATH/input || ( echo "ERROR: Failed to create directory." && exit 1 )

echo "INFO: Completed job."

