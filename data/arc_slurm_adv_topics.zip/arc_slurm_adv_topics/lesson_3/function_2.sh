#!/bin/bash

# Trap undefined variables.
set -eu

create_directory ()
{
  if mkdir -p $1
  then
    echo "INFO: Created directory."
  else 
    echo "ERROR: Failed to create directory."
    exit 1
  fi
}

MYPATH=/tmp/$USER/work/$$

if [ ! -d $MYPATH ]
then
  create_directory $MYPATH
fi
touch $MYPATH/file

create_directory $MYPATH/output
create_directory $MYPATH/input

echo "INFO: Completed job."

